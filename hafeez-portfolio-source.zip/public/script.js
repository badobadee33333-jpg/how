 "use strict";

const body = document.body;
const menuToggle = document.getElementById("menuToggle");
const menuClose = document.getElementById("menuClose");
const menuShade = document.getElementById("menuShade");
const sideMenu = document.getElementById("sideMenu");

function setMenu(open) {
  body.classList.toggle("menu-open", open);
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
  sideMenu.setAttribute("aria-hidden", String(!open));
  if (open) menuClose.focus();
  else menuToggle.focus();
}
menuToggle.addEventListener("click", () => setMenu(!body.classList.contains("menu-open")));
menuClose.addEventListener("click", () => setMenu(false));
menuShade.addEventListener("click", () => setMenu(false));
document.querySelectorAll(".menu-links a").forEach(link => link.addEventListener("click", () => setMenu(false)));
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && body.classList.contains("menu-open")) setMenu(false);
});

// Rotating role text.
const roleText = document.getElementById("roleText");
const roles = ["web experiences", "responsive interfaces", "full-stack solutions", "useful digital products"];
let roleIndex = 0;
let charIndex = roles[0].length;
let deleting = true;
function typeRole() {
  const current = roles[roleIndex];
  charIndex += deleting ? -1 : 1;
  roleText.textContent = current.slice(0, charIndex);
  let delay = deleting ? 42 : 75;
  if (!deleting && charIndex === current.length) { deleting = true; delay = 1450; }
  else if (deleting && charIndex === 0) { deleting = false; roleIndex = (roleIndex + 1) % roles.length; delay = 280; }
  window.setTimeout(typeRole, delay);
}
window.setTimeout(typeRole, 1800);

// Reveal elements as they enter the viewport.
const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => observer.observe(item));
} else revealItems.forEach(item => item.classList.add("visible"));

// Scroll progress.
const scrollProgress = document.getElementById("scrollProgress");
function updateProgress() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  scrollProgress.style.width = `${scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0}%`;
}
window.addEventListener("scroll", updateProgress, { passive: true });
updateProgress();
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form sends to the Node.js backend. It will not pretend to send when email isn't configured.
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");
const sendLabel = document.getElementById("sendLabel");
contactForm.addEventListener("submit", async event => {
  event.preventDefault();
  formStatus.textContent = "";
  formStatus.classList.remove("error");
  const button = contactForm.querySelector('button[type="submit"]');
  const payload = Object.fromEntries(new FormData(contactForm).entries());
  button.disabled = true;
  sendLabel.textContent = "Sending...";
  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.message || "Message could not be sent.");
    formStatus.textContent = result.message;
    contactForm.reset();
  } catch (error) {
    formStatus.textContent = error.message || "Unable to send right now. Please email hrrehman4545555@gmail.com directly.";
    formStatus.classList.add("error");
  } finally {
    button.disabled = false;
    sendLabel.textContent = "Send message";
  }
});