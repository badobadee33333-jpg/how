require("dotenv").config();
const express = require("express");
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/contact", async (req, res) => {
  const { name, email, subject, message, website } = req.body || {};

  // Honeypot: silently accept automated bot submissions.
  if (website) return res.json({ ok: true, message: "Message received." });

  if (![name, email, message].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ ok: false, message: "Please fill in your name, email, and message." });
  }
  if (name.length > 100 || email.length > 254 || (subject || "").length > 160 || message.length > 5000) {
    return res.status(400).json({ ok: false, message: "One or more fields are too long." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return res.status(400).json({ ok: false, message: "Please enter a valid email address." });
  }
  if (!process.env.MAIL_USER || !process.env.MAIL_APP_PASSWORD || !process.env.CONTACT_TO) {
    return res.status(503).json({
      ok: false,
      message: "The contact service is not configured yet. Please email hrrehman4545555@gmail.com directly."
    });
  }

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_APP_PASSWORD }
    });
    await transporter.sendMail({
      from: `"Hafeez Portfolio" <${process.env.MAIL_USER}>`,
      to: process.env.CONTACT_TO,
      replyTo: email.trim(),
      subject: `Portfolio message: ${(subject || "New contact").trim().slice(0, 160)}`,
      text: `New message from your portfolio\n\nName: ${name.trim()}\nEmail: ${email.trim()}\nSubject: ${(subject || "Not provided").trim()}\n\nMessage:\n${message.trim()}`
    });
    res.json({ ok: true, message: "Your message has been sent successfully. Thank you!" });
  } catch (error) {
    console.error("Contact email failed:", error.message);
    res.status(500).json({
      ok: false,
      message: "Sorry, your message could not be sent. Please email hrrehman4545555@gmail.com directly."
    });
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
